import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;



// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        // 1 ЗАДАЧА
//
//       Вывести на печать первый отрицательный элемент массива и его
////        порядковый номер, полагая, что в массиве есть хотя бы один отрицательный
////        элемент.
//
//        int[] arr = {3, 4, -2, 6, -3, 5,};
//
//        int arr2 = 0;
//
//        for (int i = 0; i < arr.length; i++) {
//            if (arr[i]<0){
//                arr2=i;
//                break;
//            }
//        }
//        if (arr2>=0){
//            System.out.println("Первый отрицательный элемент: " + arr[arr2] + ", порядковый номер: " + arr2);
//        }else {
//            System.out.println("В массиве нет отрицательных элементов.");
//        }
//
//        // 2 ЗАДАЧА
//
////        Вывести на печать номера элементов массива, удовлетворяющих
////        условию a[i]>10
//
//        int [] myArray = {1,2,33,66,8,90};
//
//        for (int i = 0; i < myArray.length; i++) {
//            if (myArray[i]>10){
//                System.out.println("Элемент с номером " + i + " удовлетворяет условию a[i] > 10: " + myArray[i]);
//            }
//        }
//
//        // 3 ЗАДАЧА
//
////        Даны   температуры   воздуха   за   неделю.   Определить   среднюю
////        температуру за неделю и сколько раз температура опускалась ниже 0º.
//
//        int [] myArray1 = new int[6];
//        myArray1[0]= 22;
//        myArray1[1]= 8;
//        myArray1[2]= -5;
//        myArray1[3]= 9;
//        myArray1[4]= -8;
//        myArray1[5]= 19;
//
//
//        int arr1=0;
//
//        for (int i = 0; i < myArray1.length; i++) {
//            if (myArray1[i]<=arr11){
//                arr11++;
//            }
//        }
//
//        int sumMyArray = Arrays.stream(myArray1).sum();
//        int average = sumMyArray / 7;
//
//        System.out.println("Темперетура воздуха в понидельник - "+myArray1[0]);
//        System.out.println("Темперетура воздуха в вторник - "+myArray1[1]);
//        System.out.println("Темперетура воздуха в среда - "+myArray1[2]);
//        System.out.println("Темперетура воздуха в четверг - "+myArray1[3]);
//        System.out.println("Темперетура воздуха в пятница - "+myArray1[4]);
//        System.out.println("Темперетура воздуха в субота - "+myArray1[5]);
//        System.out.println("Темперетура воздуха в васкрисения - "+myArray1[6]);
//        System.out.println("=====================================");
//        System.out.println("Средняя темперетура воздуха за неделю "+ average);
//        System.out.println(" Температура воздуха опускался ниже нуля:"+arr11);
//
//        // 4 ЗАДАЧА
//
//        //Даны   натуральные   числа     N,   a0,   a1,....,   a(N-1).   Определить
//        //количество членов последовательности имеющих четные порядковые номера
//        //и являющихся нечетными числами.
//
//        int[] array = {1,2,3,4,5,6,7,8,9};
//        int a = 0;
//        for (int i = 0; i < array.length; i++) {
//            if(array[i] % 2 == 1){
//                a++;
//            }
//        }
//        System.out.println("Кол-во: " + a);
//
//        // 5 ЗАДАЧА
//
////        Определить является ли данная последовательность убывающей (во
////        избежание лишних проверок использовать оператор break)
//
//        int[] sequence = {10, 8, 6, 4, 2};
//
//        boolean isDescending = true;
//
//        for (int i = 1; i < sequence.length; i++) {
//            if (sequence[i] >= sequence[i - 1]) {
//                isDescending = false;
//                break;
//            }
//        }
//
//        if (isDescending) {
//            System.out.println("Последовательность является убывающей.");
//        } else {
//            System.out.println("Последовательность не является убывающей.");
//        }
//
//        // 6 ЗАДАЧА
//
////        Дан массив чисел. Определить, сколько в нем пар одинаковых
////        соседних элементов
//
//        int[] arra = {1, 2, 2, 3, 3, 4, 4, 5};
//
//        int countPairs = 0;
//
//        for (int i = 1; i < arra.length; i++) {
//                if (arra[i-1]==arra[i]){
//                    countPairs++;
//                }
//            }
//        System.out.println("Количество пар одинаковых соседних элементов: " + countPairs);
//
//        // 7 ЗАДАЧА
//
//        //Дан   массив   чисел.   Найти   наибольший   элемент,   поставить   его
//        //первым.
//
//        int[] aa = {3, 4, 56, 7, 900, 84, 3, 4, 5,};
//        int b = aa[0];
//        int c = 0;
//        for (int i = 0; i < aa.length; i++) {
//            if (aa[i] > b) {
//                b = aa[i];
//                c = i;
//            }
//        }
//        int v = aa[0];
//        aa[0] = b;
//        aa[c] = v;
//        for (int d : aa) {
//            System.out.print(d + " ");
//        }
//
//
//        //8 ЗАДАЧА
//
//    //Задан двумерный массив, содержащий 3 строки и 4 столбца. Найти
//    //наибольший элемент, номер строки и столбца, в которых он расположен.
//
//    int[][] array = {
//            {1, 5, 9, 13},
//            {3, 7, 99, 15},
//            {2, 6, 10, 14}
//    };
//
//    int maxElement = array[0][0];
//    int row = 0;
//    int column = 0;
//
//        for (int i = 0; i < array.length; i++) {
//        for (int j = 0; j < array[i].length; j++) {
//        if (array[i][j] > maxElement) {
//        maxElement = array[i][j];
//        row = i;
//        column = j;
//
//        }
//
//        }
//
//        }
//
//        System.out.println("Наибольший элемент: " + maxElement);
//        System.out.println("Номер строки: " + row);
//        System.out.println("Номер столбца: " + column);
//
//        // 9 ЗАДАЧА
//
//        // Составить программу для вычисления средних арифметических
//        //значений положительных элементов каждого столбца двумерного массива,
//        //содержащего 6 столбцов и три строки. При условии, что в каждом столбце
//        //есть хотя бы один положительный элемент
//
//        int[][] array = {
//                {1, 2, -3, 4, -5, 6},
//                {-1, 2, 3, 4, 5, -6},
//                {6, -5, 4, -3, 2, 1}
//        };
//
//        int columns = array[0].length;
//        int rows = array.length;
//
//        for (int col = 0; col < columns; col++) {
//            int sum = 0;
//            int count = 0;
//
//            for (int row = 0; row < rows; row++) {
//                if (array[row][col] > 0) {
//                    sum += array[row][col];
//                    count++;
//                }
//            }
//
//            if (count > 0) {
//                double average = (double) sum / count;
//                System.out.println("Среднее значение столбца " + col + ": " + average);
//            } else {
//                System.out.println("В столбце " + col + " нет положительных элементов");
//            }
//            }
        // 10
        //Присвоить элементам массива уникальные случайные значения, то
        //есть требуется заполнить массив случайными числами, но при этом каждое
        //число   в   массиве   должно   встречаться   не   более   одного   раза.   При
        //проектировании такого алгоритма сразу следует выделить особую ситуацию
        //– если размер массива будет больше, чем число различных случайных чисел,
        //генерируемых генератором ПСЧ, то решить задачу будет невозможно
//         Random random = new Random();int [] array ={2,3,4,5,6};
//        for (int i = 0; i < array.length; i++) {
//            int randomNum = random.nextInt(-10,10);
//            if (Arrays.binarySearch(array,randomNum) < 0){         System.out.println(randomNum);
//            }
//        }
        // 11
        //Дана действительная квадратная матрица. Заменить нулями все
        //элементы, расположенные на главной диагонали и  выше нее
//        int [] matrix = {1,2,3,4,5,6,7,8};
//        for (int i = 0; i < matrix.length; i++) {
//            for (int j = 0; j < 8; j++){
//                System.out.print(matrix[j]+ " " );
//            }
//
//        }
//
//        int [] array = {1,2,3,4,5};
//        int [] array1 = {6,7,8,9,10};
//        int [] join = new int[array.length+array1.length];
//        int counter=0;
//        for (int i = 0; i < array.length; i++) {
//            join[i]=array[i];
//            counter++;
//        }
//        for (int i = 0; i <array1.length ; i++) {
//            join[counter++]=array1[i];
//        }
//        System.out.println(Arrays.toString(join));


        // 12
        //Даны 8 действительных чисел х1, х2, ..., х8. Получить квадратную
        //матрицу 8х8
//        int [] matrix = {6,5,4,3,2,5,6,8};
//        for (int i = 0; i < matrix.length; i++) {
//            for (int j = 0; j < 8; j++){
//                System.out.print(matrix[j]+ " " );
//            }
//            System.out.println();
//        }
        //13
        // ан   двумерный   массив,   содержащий   3   строки   и   4   столбца.
        //Упорядочить массив по убыванию элементов 3-ей строки
//        int[][] arr1 = {
//                {11, 7,34,21},
//                {7, 3,87,56},
//                {3, 23,75,5},
//
//        };
//        for (int i = 0; i < arr1.length - 1; i++) {
//            for (int j = 0; j < arr1.length - i - 1; j++) {
//                if (arr1[j][2] > arr1[j + 1][2]) {
//                    int[] temp = arr[j];
//                    arr1[j] = arr1[j + 1];
//                    arr1[j + 1] = temp;
//                }
//            }
//        }
//        for (int[] row : arr1) {
//            System.out.print(row[2] + " ");
//        }
        //14
        //Дан двумерный массив, содержащий 5 строк и 2 столбца. Упорядочить
        //массив по возрастанию элементов 2-го столбца
//        int[][] arr1 = {
//                {-11, 2,},
//                {7, 3,},
//                {3, 23,},
//                {25, 14,},
//                {13, 18,}
//        };
//        for (int i = 0; i < arr1.length - 1; i++) {
//            for (int j = 0; j < arr1.length - i - 1; j++) {
//                if (arr1[j][1] > arr1[j + 1][1]) {
//                    int[] temp = arr[j];
//                    arr1[j] = arr[j + 1];
//                    arr1[j + 1] = temp;
//                }
//            }
//        }
//        for (int[] row : arr1) {
//            System.out.print(row[1] + " ");
//        }
        //15
        //Даны целые числа  . Получить целочисленную матрицу  b
        //каждый элемент, которой определяется  по следующей формуле
        //, i, j=0,1,2.
//        int[] a = {1, 2, 3};
//        int[][] b = new int[3][3];
//        for (int i = 0; i < 3; i++) {
//            for (int j = 0; j < 3; j++) {
//                b[i][j] = a[i] + a[j];
//            }
//        }
//        for (int i = 0; i < 3; i++) {
//            for (int j = 0; j < 3; j++) {
//                System.out.print(b[i][j] + " ");
//            }
//            System.out.println();
//
//        }
        //17
        //Найти   наибольший   элемент   главной   диагонали   матрицы   С
        //размером 4х4 и вывести на печать всю строку, в которой он находится
//        int[][] matrix = {
//                {4,5,6,7},
//                {4,5,6,7,8},
//                {45,67,66,34},
//                {4,5,6,7,8}
//        };
//        int maxElement = matrix[0][0];
//        int maxRow = 0;
//        for (int i = 0; i < matrix.length; i++) {
//            if (matrix[i][i] > maxElement) {
//                maxElement = matrix[i][i];
//                maxRow = i;
//            }
//        }
//        System.out.println("Наибольший элемент на главной диагонали: " + maxElement);
//        System.out.print("Строка с наибольшим элементом: ");
//        for (int j = 0; j < matrix[maxRow].length; j++) {
//            System.out.print(matrix[maxRow][j] + " ");
        //18
        //Подсчитать количество простых чисел в двумерном массиве,
        //состоящем из целых чисел, полученных случайным образом


        //19
        //Напишите код, который создает 20 случайных чисел диапазона
        //1 - 99. Следует вывести в консоль только те числа которые делятся на 1-
        //ое рандомное число без остатка
        //       Random random = new Random();
//        int[] massiv2 = new int[10];
//        for (int i = 0; i < 10; i++) {
//            massiv2[i] = random.nextInt(0,99);
//        }
//        int a = random.nextInt(0,99);
//        System.out.println("рандомное число");
//        for (int b:massiv) {
//            if (b%a == 0) {
//                System.out.println(b );
//            }
//        }
//        System.out.println(Arrays.toString(massiv2))
        //20
        //Напишите код, который генерирует 20 рандомных целых чисел
        //из диапазона -50 до +50, и определяет наименьшее число и
        //наибольшее число. Нельзя использовать массив


        //21
        //Напишите код, который принимает с консоли для переменной X
        //целое положительное число, а затем дополнительно будет
        //спрашивать ещё числа, эти числа будут должны вычитаться из
        //переменной x, вы будете вводить числа до тех пор пока X не будет
        //отрицательным или равен 0.  используйте while loop
        //Напишите класс, который принимает с клавиатуры две
        //переменный это два числа, пока не будет введено две одинаковых чисел


        //22
        //Найти второй наибольший элемент в массиве
//        int [] massive1 = {3,4,55,6,7,8,9};int Max = massive1[0];
//        for (int i = 0; i < massive1.length-1; i++) {    if (massive1[i] > Max){
//            Max = massive1[i];            }}
//        System.out.println("большой Элемент:"+Max);
        //23
        //.Объединить два массива в третий массив:
//        int [] array1 = {1,2,3,4,5};
//        int [] array1 = {6,7,8,9,10};
//        int [] join = new int[array1.length+array1.length];
//
//        int counter=0;
//        for (int i = 0; i < array1.length; i++) {
//            join[i]=array1[i];
//            counter++;
//        }
//        for (int i = 0; i <array1.length ; i++) {
//            join[counter++]=array1[i];
//        }
//        System.out.println(Arrays.toString(join));

        //24
        //Найти минимальное значение в массиве.

        //25
        // напишите программу для добавления нового элемента в массив
//        System.out.println("Наш первоначальный масив");
//        int [] masiv = {1,4,65,6,2};
//        System.out.println(Arrays.toString(masiv));
//        System.out.println("Напишите цыфру которую хатите добавить:");
//        int dd = scanner.nextInt();
//
//        int []  newMassiv;
//
//        newMassiv = Arrays.copyOf(masiv,masiv.length+1);
//        newMassiv[newMassiv.length-1]=dd;
//        System.out.println(Arrays.toString(newMassiv));
//        masiv=Arrays.copyOf(newMassiv,newMassiv.length);
//        System.out.println("Наш массив после добавления");
    }
}








